# Training Report

## Model Training Summary

| Model | Training Time (s) | Best Parameters |
|-------|-------------------|----------------|
| Decision Tree | 403.33 | N/A |
| Naive Bayes | 402.56 | N/A |
| K-Nearest Neighbors | 402.76 | N/A |
| Logistic Regression | 402.26 | N/A |
| Random Forest | 403.8 | N/A |
| XGBoost | 403.15 | N/A |
